<?php

use App\Http\Controllers\DataWargaController;
use App\Http\Controllers\LoginUser;
use App\Http\Controllers\RegisterUser;
use App\Models\DataWarga;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/coba', function () {
    return view('coba');
});

Route::get('/loginadmin', function () {
    return view('loginadmin');
});

Route::get('/login', function () {
    return view('loginuser');
})->name('login'
);

Route::get('/registeruser', function () {
    return view('registeruser');
});


Route::get('/dashboardadmin', function () {
    return view('dashboardadmin');
})->middleware(['auth','verified'])->name('dashboardadmin');;


Route::get('/dashboarduser', function () {
    return view('dashboarduser');
})->middleware(['auth','verified'])->name('dashboarduser');

Route::get('/datawarga', function () {
    return view('datawarga',[
        'data'=> DataWarga::all(),
    ]);
});


Route::get('/userdatadiri', function () {
    return view('userdatadiri');
});

Route::get('/usereditdata', function () {
    return view('usereditdata');
});


Route::get('/usereditd', function () {
    return view('pengalihan');
});

Route::post('/registeruser', [RegisterUser::class, 'store'])->name('registeruser');


Route::post('/loginuser',[ LoginUser::class ,'login'] )->name('loginuser');

Route::post('/userdatadiri',[DataWargaController::class ,'store'] )->name('userdatadiri');

Route::post('/logout', function () {
    Auth::logout();
    return redirect('/coba')->with('success', 'Logout berhasil!');
})->name('logout');


Route::get('/datawarga/delete/id={DataWarga:id}',[DataWargaController::class ,'destroy'] );

Route::get('/datawarga/update/id={DataWarga:id}',[DataWargaController::class ,'index'] );
Route::post('/datawarga/update/id={DataWarga:id}',[DataWargaController::class ,'update'] );



