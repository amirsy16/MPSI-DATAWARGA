<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Data Warga</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<style>
     .sidebar {
      background-color: #007bff;
      height: 100vh;
      width: 35vh;
      padding-top: 20px;
    }

    
</style>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 bg-primary sidebar ">
                <ul class="nav  d-flex  flex-column justify-content-center align-item-center">
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="dashboardadmin">Beranda</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active text-white" href="datawarga">Data Warga</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="#">Surat</a>
                    </li>
                    <li class="nav-item ">
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="btn btn-danger">Logout</button>
                        </form>
                    </li>
                </ul>
            </div>
            <div class="col-md-9">
                <h2 class="mt-3">Data Warga</h2>
                <p>Selamat datang di website RT 04 Lorong kemajuan, Mendalo</p>
                <table class="table">
                    <thead>
                        @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif
                        <tr>
                            <th>Nama Lengkap</th>
                            <th>NIK</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Pekerjaan</th>
                            <th>Status Perkawinan</th>
                            <th>Agama</th>
                            <th>Kontak</th>
                            <th>action</th>
                        </tr>
                        @foreach ($data as $e)
                        <tr>
                            <td>{{ $e['nama_lengkap'] }}</td>
                            <td>{{ $e['nik'] }}</td>
                            <td>{{ $e['tanggal_lahir'] }}</td>
                            <td>{{ $e['jenis_kelamin'] }}</td>
                            <td>{{ $e['pekerjaan'] }}</td>
                            <td>{{ $e['status_perkawinan'] }}</td>
                            <td>{{ $e['agama'] }}</td>
                            <td>{{ $e['kontak'] }}</td>
                            <td>
                                <a href="/datawarga/delete/id={{$e['id']}} " onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">delete</a>
                                <a href="/datawarga/update/id={{$e['id']}}">update</a>
                            </td>
                        </tr>
                        @endforeach
                    </thead>
                    <tbody>
                        </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>