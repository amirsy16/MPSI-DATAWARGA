<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
.pilihan-login{
    height: 100vh;
    background: linear-gradient(to bottom, #e0f7ff, #7bbcff);
      height: 100vh;
}



</style>
</head>
  <body>
    <section id="pilihan-login" class="bg-primary h-100">

   <div class="pilihan-login  d-flex justify-content-center flex-column align-items-center py-5">


    <h1>Pilih tipe Akun</h1>

    <div class="pilihan d-flex gap-3">
     <a href="/dashboardadmin" class="admin rounded-4 bg-secondary p-5 d-flex flex-column justify-content-center flex-column align-items-center">
        <img src="img/Admin Settings Male.png" alt="">
        <span>admin</span>
    </a>

    <a href="dashboarduser" class="admin rounded-4 bg-secondary p-5 d-flex flex-column justify-content-center flex-column align-items-center">
        <img src="img/User.png" alt="">
        <span>warga</span>
    </a>
    
    </div>

        <p>Belum mempunyai akun? <a href="/registeruser" class="text-secondary">Daftar disini</a> </p>
 

   
   </div>


</section>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>