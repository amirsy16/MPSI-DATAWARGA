<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('data_wargas', function (Blueprint $table) {
            $table->id(); // Primary key
            $table->string('nama_lengkap'); // Kolom untuk nama lengkap
            $table->string('nik')->unique(); // Kolom untuk NIK, harus unik
            $table->date('tanggal_lahir'); // Kolom untuk tanggal lahir
            $table->string('jenis_kelamin'); // Kolom untuk jenis kelamin
            $table->string('pekerjaan'); // Kolom untuk pekerjaan
            $table->string('status_perkawinan'); // Kolom untuk status perkawinan
            $table->string('agama'); // Kolom untuk agama
            $table->string('kontak'); // Kolom untuk kontak
            $table->timestamps(); // Kolom created_at dan updated_at otomatis
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('data_wargas');
    }
};
