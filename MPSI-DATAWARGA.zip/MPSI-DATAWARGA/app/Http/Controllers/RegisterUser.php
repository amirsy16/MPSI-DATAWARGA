<?php

namespace App\Http\Controllers;

use App\Models\DataWarga;
use App\Models\User;
use Illuminate\Http\Request;

class RegisterUser extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $dataWarga = DataWarga::all();
        return view('datawarga.index', compact('dataWarga'));
    }

    /**
     * Store a newly created resource in storage.
     */
 
    
    public function store(Request $request)
    {
        // Validate the incoming request data
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8', // Assuming password confirmation is required
        ]);
    
        // // Hash the password before saving
        // $validatedData['password'] = bcrypt($validatedData['password']);
    
        // Create the user with validated data
        User::create($validatedData);
    
        // Redirect or return a view after successful registration
        return view('/loginuser');
    }
    
    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        //
    }
}
