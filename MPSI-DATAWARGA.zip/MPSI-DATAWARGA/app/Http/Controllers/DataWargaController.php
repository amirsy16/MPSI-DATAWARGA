<?php

namespace App\Http\Controllers;

use App\Models\DataWarga;
use Illuminate\Http\Request;

class DataWargaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index($id)
    {
        // Mencari data warga berdasarkan ID
        $dataWarga = DataWarga::findOrFail($id);
    
        // Mengembalikan view dengan data warga
        return view('usereditdata', ['datawarga' => $dataWarga]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
           // Validasi input data
           $validatedData = $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'nik' => 'required|string|max:16|unique:data_wargas,nik',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required|string',
            'pekerjaan' => 'required|string|max:255',
            'status_perkawinan' => 'required|string',
            'agama' => 'required|string',
            'kontak' => 'required|string|max:15',
        ]);
      
        
        // Simpan data warga baru menggunakan array dari validasi
        DataWarga::create($validatedData);
        return redirect('/userdatadiri')->with('success', 'Data berhasil disimpan!');
    }

    /**
     * Display the specified resource.
     */
    public function show(DataWarga $dataWarga)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DataWarga $dataWarga)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request ,$id)
    {      $validatedData = $request->validate([
        'nama_lengkap' => 'required|string|max:255',
        'nik' => 'required|string|max:16',
        'tanggal_lahir' => 'required|date',
        'jenis_kelamin' => 'required|string',
        'pekerjaan' => 'required|string|max:255',
        'status_perkawinan' => 'required|string',
        'agama' => 'required|string',
        'kontak' => 'required|string|max:15',
    ]);

        $Warga = DataWarga::findOrFail($id);
        // Mengupdate data warga menggunakan data yang telah divalidasi
        $Warga->update($validatedData);
    
        // Redirect kembali ke halaman daftar data warga dengan pesan sukses
        return redirect('/datawarga')->with('success', 'Data berhasil diperbaharui!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Cari data warga berdasarkan ID
        $dataWarga = DataWarga::findOrFail($id);
        
        // Hapus data warga
        $dataWarga->delete();

        // Redirect dengan pesan sukses
        return redirect('/datawarga')->with('success', 'Data berhasil dihapus!');
    }
}
