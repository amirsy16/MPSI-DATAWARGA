<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login User</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      height: 100vh;
      background: linear-gradient(to bottom, #e0f7ff, #7bbcff);
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .login-container {
      background-color: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
      max-width: 400px;
      width: 100%;
      text-align: center;
      height: 55vh;
      width: 50vh;
    }
    .login-container h2 {
      margin-bottom: 30px;
      font-size: 24px;
      font-weight: bold;
      color: #4b4bfc;
    }
    .form-control {
      margin-bottom: 20px;
      border-radius: 8px;
      height: 45px;
    }
    .btn-primary {
      background-color: #0056b3;
      border-color: #0056b3;
      width: 100%;
      height: 45px;
      border-radius: 8px;
    }
    .btn-primary:hover {
      background-color: #004494;
      border-color: #004494;
    }
  </style>
</head>
<body>

  <div class="login-container">
    <h2>Login sebagai User</h2>
    <form method="POST" action="/loginuser">
      <?php echo csrf_field(); ?>
      <div class="mb-2">
        <input type="email" name="email" class="form-control" id="email" placeholder="Email">
      </div>
      <div class="mb-3">
        <input type="password" name="password" class="form-control" id="password" placeholder="Password">
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\MPSI-DATAWARGA\resources\views/loginuser.blade.php ENDPATH**/ ?>