<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f0f0;
    }
    .sidebar {
      background-color: #007bff;
      height: 100vh;
      width: 35vh;
      padding-top: 20px;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      padding: 10px 20px;
      display: block;
    }
    .sidebar a:hover {
      background-color: #0056b3;
    }
    .content {
      margin-left: 1px;
      padding: 10px;
    }
    /* Flexbox untuk menyamakan tinggi kartu */
    .card {
      padding: 50px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
      min-height: 260px; /* Tinggi minimum yang sama untuk semua kartu */
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
    /* Atur ukuran gambar agar semua gambar seragam */
    .card img {
      width: 60px; /* Anda bisa sesuaikan ukuran ini */
      margin-bottom: 10px;
    }
    .header {
      background-color: #f8f9fa;
      padding: 10px 20px;
      border-bottom: 2px solid #e0e0e0;
      width: 180vh;
      
    }
  </style>
</head>
<body>

  <div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar d-flex  flex-column">
      <a href="/Beranda">Beranda</a>
      <a href="/datawarga">Data Warga</a>
      <a href="">Surat</a>
      <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
    </div>

    <!-- Main Content -->
    <div class="content">
      <!-- Header -->
      <div class="header">
        <h3>Beranda</h3>
        <p>Selamat datang di website RT 04 Lorong Kemajuan, Menado</p>
      </div>

      <!-- Dashboard Cards -->
      <div class="row d-flex justify-content-center mt-4">
        <div class="col-md-3">
          <div class="card">
            <img src="img/Visitor.png" alt="Icon Pengguna">
            <h4>32</h4>
            <p>Jumlah Pengguna</p>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <img src="img/Caretaker.png" alt="Icon Warga">
            <h4>60</h4>
            <p>Jumlah Warga</p>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <img src="img/Document.png" alt="Icon Surat">
            <h4>30</h4>
            <p>Surat yang telah diproses</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS (optional) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\MPSI-DATAWARGA\resources\views/dashboardadmin.blade.php ENDPATH**/ ?>