<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Data Warga</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<style>
     .sidebar {
      background-color: #007bff;
      height: 100vh;
      width: 35vh;
      padding-top: 20px;
    }

    
</style>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 bg-primary sidebar ">
                <ul class="nav  d-flex  flex-column justify-content-center align-item-center">
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="dashboardadmin">Beranda</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active text-white" href="datawarga">Data Warga</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="#">Surat</a>
                    </li>
                    <li class="nav-item ">
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">Logout</button>
                        </form>
                    </li>
                </ul>
            </div>
            <div class="col-md-9">
                <h2 class="mt-3">Data Warga</h2>
                <p>Selamat datang di website RT 04 Lorong kemajuan, Mendalo</p>
                <table class="table">
                    <thead>
                        <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
                        <tr>
                            <th>Nama Lengkap</th>
                            <th>NIK</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Pekerjaan</th>
                            <th>Status Perkawinan</th>
                            <th>Agama</th>
                            <th>Kontak</th>
                            <th>action</th>
                        </tr>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($e['nama_lengkap']); ?></td>
                            <td><?php echo e($e['nik']); ?></td>
                            <td><?php echo e($e['tanggal_lahir']); ?></td>
                            <td><?php echo e($e['jenis_kelamin']); ?></td>
                            <td><?php echo e($e['pekerjaan']); ?></td>
                            <td><?php echo e($e['status_perkawinan']); ?></td>
                            <td><?php echo e($e['agama']); ?></td>
                            <td><?php echo e($e['kontak']); ?></td>
                            <td>
                                <a href="/datawarga/delete/id=<?php echo e($e['id']); ?> " onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">delete</a>
                                <a href="/datawarga/update/id=<?php echo e($e['id']); ?>">update</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </thead>
                    <tbody>
                        </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\MPSI-DATAWARGA\resources\views/datawarga.blade.php ENDPATH**/ ?>