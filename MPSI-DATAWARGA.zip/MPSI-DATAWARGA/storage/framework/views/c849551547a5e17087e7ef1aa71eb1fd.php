<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Data Diri</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #007bff;
            min-height: 100vh;
            color: white;
            padding-top: 20px;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #0056b3;
            
        }

        .content {
            background-color: #f4f4f4;
            padding: 20px;
        }

        .header {
            background-color: #e9ecef;
            padding: 10px;
            font-size: 24px;
        }

        .edit-link {
            text-align: right;
            font-size: 14px;
        }

        .edit-link a {
            color: #007bff;
            text-decoration: none;
        }

        .edit-link a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

    <div class="container-fluid">
        
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <a href="dashboarduser">Beranda</a>
                <a href="userdatadiri">Data Diri</a>
                <a href="surat">Surat</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
            </div>


            <!-- Content -->
            <div class="col-md-9">
                <?php echo $__env->yieldContent('content'); ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>  
                <div class="header d-flex justify-content-between align-items-center">
                    <span>Data Diri</span>
                    <span>Selamat datang di website RT 04 Lorong Kemajuan, Mendalo</span>
                </div>

               

                <!-- Form Data Diri -->
                <form method="POST" action ="/userdatadiri" class= "mt-3 ">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="namaLengkap"  class="form-label">Nama Lengkap</label>
                        <input type="text" name="nama_lengkap" class="form-control" id="namaLengkap" placeholder="Nama Lengkap">
                    </div>
                    <div class="mb-3">
                        <label for="nik" class="form-label">NIK</label>
                        <input type="text" name="nik" class="form-control" id="nik" placeholder="NIK">
                    </div>
                    <div class="mb-3">
                        <label for="tanggalLahir" class="form-label">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" class="form-control" id="tanggalLahir">
                    </div>
                    <div class="mb-3">
                        <label for="jenisKelamin" class="form-label">Jenis Kelamin</label>
                        <input type="text" name="jenis_kelamin" class="form-control" id="jenisKelamin" placeholder="Jenis Kelamin">
                    </div>
                    <div class="mb-3">
                        <label for="pekerjaan" class="form-label">Pekerjaan</label>
                        <input type="text" name="pekerjaan" class="form-control" id="pekerjaan" placeholder="Pekerjaan">
                    </div>
                    <div class="mb-3">
                        <label for="statusPerkawinan" class="form-label">Status Perkawinan</label>
                        <input type="text" name="status_perkawinan" class="form-control" id="statusPerkawinan" placeholder="Status Perkawinan">
                    </div>
                    <div class="mb-3">
                        <label for="agama" class="form-label">Agama</label>
                        <input type="text" name="agama" class="form-control" id="agama" placeholder="Agama">
                    </div>
                    <div class="mb-3">
                        <label for="kontak" class="form-label">Kontak</label>
                        <input type="text" name="kontak" class="form-control" id="kontak" placeholder="Kontak">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                   

                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\MPSI-DATAWARGA\resources\views/userdatadiri.blade.php ENDPATH**/ ?>